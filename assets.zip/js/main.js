// R17 ESCAPE · main.js
(function(){
  // Parallax scroll
  const back = document.querySelector('.layer-back');
  window.addEventListener('scroll', () => {
    const y = window.scrollY;
    if(back) back.style.transform = `translateY(${y * 0.35}px) scale(1.15)`;
  }, { passive:true });

  // Mouse parallax en hero
  const hero = document.querySelector('.hero');
  if(hero && back){
    hero.addEventListener('mousemove', (e) => {
      const r = hero.getBoundingClientRect();
      const x = (e.clientX - r.width/2) / r.width;
      const y = (e.clientY - r.height/2) / r.height;
      back.style.backgroundPosition = `${50 + x*4}% ${50 + y*4}%`;
    });
  }

  // Highlight nav activa
  const sections = document.querySelectorAll('section[id]');
  const navBtns  = document.querySelectorAll('.nav-btn');
  const navObs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if(e.isIntersecting){
        const id = e.target.id;
        navBtns.forEach(b => b.classList.toggle('active', b.getAttribute('href') === '#' + id));
      }
    });
  }, { threshold: 0.4 });
  sections.forEach(s => navObs.observe(s));

  // Reveal on scroll
  document.querySelectorAll('.section, .lore-card, .level-card, .control-card, .timeline li, .engine-card').forEach(el => {
    el.classList.add('reveal');
  });
  const revealObs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if(e.isIntersecting){
        e.target.classList.add('in');
        revealObs.unobserve(e.target);
      }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll('.reveal').forEach(el => revealObs.observe(el));

  // Counters animados
  const counters = document.querySelectorAll('[data-count]');
  const counterObs = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if(e.isIntersecting){
        const el = e.target;
        const target = parseInt(el.dataset.count, 10);
        let cur = 0;
        const step = Math.max(1, Math.floor(target / 40));
        const tick = () => {
          cur += step;
          if(cur >= target){ el.textContent = target; return; }
          el.textContent = cur;
          requestAnimationFrame(tick);
        };
        tick();
        counterObs.unobserve(el);
      }
    });
  }, { threshold: 0.5 });
  counters.forEach(c => counterObs.observe(c));

  // Botón volver arriba
  const toTop = document.getElementById('toTop');
  window.addEventListener('scroll', () => {
    toTop.classList.toggle('show', window.scrollY > 600);
  });
  toTop.addEventListener('click', () => window.scrollTo({top:0, behavior:'smooth'}));

  // Easter egg "r17"
  let buf = '';
  window.addEventListener('keydown', e => {
    buf = (buf + e.key.toLowerCase()).slice(-3);
    if(buf === 'r17'){
      document.body.style.transition = 'filter .3s';
      document.body.style.filter = 'hue-rotate(180deg) invert(.05)';
      setTimeout(() => document.body.style.filter = '', 1200);
    }
  });

  // Lightbox del logo
  const brand = document.getElementById('brandLogo');
  const lb = document.getElementById('logoLightbox');
  if(brand && lb){
    brand.addEventListener('click', (e) => {
      e.preventDefault();
      lb.classList.add('show');
      lb.setAttribute('aria-hidden','false');
    });
    lb.addEventListener('click', () => {
      lb.classList.remove('show');
      lb.setAttribute('aria-hidden','true');
    });
  }

  // R17 corriendo por la pantalla + interacción con el mouse
  const r17 = document.getElementById('runningR17');
  if(r17){
    let x = -120;
    const speed = 1.6;
    function loop(){
      x += speed;
      if(x > window.innerWidth + 120) x = -120;
      r17.style.left = x + 'px';
      requestAnimationFrame(loop);
    }
    loop();

    // Cuando el mouse pasa cerca, "salta" con efecto
    window.addEventListener('mousemove', (ev) => {
      const rect = r17.getBoundingClientRect();
      const cx = rect.left + rect.width/2;
      const cy = rect.top + rect.height/2;
      const dx = ev.clientX - cx;
      const dy = ev.clientY - cy;
      const dist = Math.hypot(dx, dy);
      if(dist < 120){
        r17.src = 'assets/r17_jump1.png';
        r17.classList.add('jump');
        clearTimeout(r17._t);
        r17._t = setTimeout(() => {
          r17.classList.remove('jump');
          r17.src = 'assets/r17_walk.gif';
        }, 600);
      }
    });
  }

  // Equipo desplegable
  const teamBtn = document.getElementById('teamToggle');
  const teamList = document.getElementById('teamList');
  if(teamBtn && teamList){
    teamBtn.addEventListener('click', () => {
      teamList.hidden = !teamList.hidden;
    });
  }
})();
